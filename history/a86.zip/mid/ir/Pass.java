package mid.ir;

public class Pass extends Instruction {



}
