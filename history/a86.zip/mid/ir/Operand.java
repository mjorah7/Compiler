package mid.ir;

public interface Operand {

    String value2Ir();

    String type2Ir();

    String all2Ir();

}
