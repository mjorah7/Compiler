package mid;

import frontend.Symbol;
import mid.ir.Number;
import mid.ir.Operand;

import java.util.ArrayList;
import java.util.List;

public class TempCounter {

    private int cnt = 0;

    public Symbol getTemp(int level) {
        return new Symbol("-t" + (cnt++), Symbol.VarType.VAR, Symbol.ValueType.INT, false, null, level);
    }

    public Symbol getPointer(int level, Symbol base, List<Operand> index) {
        List<Integer> dim = new ArrayList<>();
        dim.add(0);
        dim.addAll(base.dimensions);
        for (int i = 1; i < index.size(); i++) {
            dim.remove(1);
        }
        return new Symbol(Symbol.VarType.POINTER, Symbol.ValueType.INT, "-t" + (cnt ++), dim, level);
    }

}
