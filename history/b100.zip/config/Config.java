package config;

public class Config {

    public static final boolean LLVM = true;

}
