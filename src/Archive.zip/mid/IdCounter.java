package mid;

public class IdCounter {

    private int cnt = 0;

    public int getId() {
        return cnt ++;
    }

}
