package config;

public class Config {

    public static final boolean LLVM = true;

    public static boolean DEBUG = true;

}
